# Multani Mithas

Premium Pakistani Sweets & Bakery E-Commerce + Business Management System.

## Current phase
Stage 1 — Project foundation

## Media
The site is designed from the beginning to support:
- Product images
- Hero/banner images
- Promotional images
- Customer/review images
- Optimized video backgrounds
- Product/demo videos
- Responsive media
- Lazy loading and poster images

## Planned stack
- Next.js
- TypeScript
- Tailwind CSS
- PostgreSQL
- Prisma
- Role-based authentication
- Object storage/CDN for production media

The payment gateway and map provider remain configurable and will be selected later.
