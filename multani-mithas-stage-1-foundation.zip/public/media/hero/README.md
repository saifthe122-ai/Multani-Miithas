Add the homepage hero assets here.

Expected:
- hero-poster.webp — optimized poster/fallback image
- hero.mp4 — short compressed promotional video

The application falls back to the poster image when video is unavailable or reduced-motion is enabled.
