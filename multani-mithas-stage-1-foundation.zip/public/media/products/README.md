Add optimized product images here.

Current homepage expects:
- sohan-halwa.webp
- barfi.webp
- gulab-jamun.webp
- gift-box.webp
