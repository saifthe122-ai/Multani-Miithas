# Stage 1 — Project Foundation

## Architecture

The system is planned around a modern web application with:
- Customer storefront
- Customer authentication/account area
- Admin management area
- Delivery-boy area
- Backend/API
- PostgreSQL database
- Object storage/CDN for media

## Media architecture

Media is a first-class part of the system.

### Image types
- Product gallery
- Product thumbnails
- Hero images
- Promotional banners
- Category images
- Gift-box imagery
- Review/customer images
- Admin-uploaded media

### Video types
- Homepage promotional/hero video
- Product videos
- Campaign videos
- Optional promotional clips

### Performance rules
- Use responsive image sizes.
- Lazy-load below-the-fold media.
- Use video poster images.
- Avoid autoplay audio.
- Prefer compressed WebP/AVIF images.
- Prefer MP4/WebM video where appropriate.
- Do not load large video files on mobile unless appropriate.
- Production media should be served through object storage/CDN.

## Current state

No previous application code existed. This repository is the clean starting foundation.

## Next exact action

Build the homepage visual system with:
1. Premium hero section
2. Hero image/video media support
3. Featured products
4. Best sellers
5. Offers
6. Gift boxes
7. Why Multani Mithas
8. Delivery information
9. Customer reviews
10. WhatsApp/contact CTA
