import "./globals.css";

export const metadata = {
  title: "Multani Mithas",
  description: "Premium Pakistani sweets and bakery.",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
