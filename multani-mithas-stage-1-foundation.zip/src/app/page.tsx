import Image from "next/image";

const featured = [
  { name: "Sohan Halwa", image: "/media/products/sohan-halwa.webp" },
  { name: "Barfi", image: "/media/products/barfi.webp" },
  { name: "Gulab Jamun", image: "/media/products/gulab-jamun.webp" },
  { name: "Gift Boxes", image: "/media/products/gift-box.webp" },
];

export default function Home() {
  return (
    <main>
      <section className="hero">
        <div className="hero-media" aria-hidden="true">
          <video
            className="hero-video"
            autoPlay
            muted
            loop
            playsInline
            poster="/media/hero/hero-poster.webp"
          >
            <source src="/media/hero/hero.mp4" type="video/mp4" />
          </video>
        </div>

        <div className="hero-overlay" />
        <div className="hero-content">
          <p className="eyebrow">Tradition • Taste • Mithas</p>
          <h1>Premium Mithas, Made the Multani Way.</h1>
          <p>
            Discover handcrafted Pakistani sweets, bakery favourites and
            thoughtfully packed gifts.
          </p>
          <div className="actions">
            <a href="#featured" className="button button-primary">Explore Sweets</a>
            <a href="#contact" className="button button-secondary">Order on WhatsApp</a>
          </div>
        </div>
      </section>

      <section id="featured" className="section">
        <div className="section-heading">
          <p className="eyebrow">Our favourites</p>
          <h2>Made for every sweet moment</h2>
        </div>

        <div className="product-grid">
          {featured.map((product) => (
            <article className="product-card" key={product.name}>
              <div className="product-image">
                <Image
                  src={product.image}
                  alt={product.name}
                  fill
                  sizes="(max-width: 768px) 100vw, 25vw"
                />
              </div>
              <h3>{product.name}</h3>
            </article>
          ))}
        </div>
      </section>

      <section className="media-note section">
        <div>
          <p className="eyebrow">Media-ready foundation</p>
          <h2>Beautiful images and video without slowing the shop down.</h2>
          <p>
            Product photography, promotional banners and short brand videos
            can be added through the media structure from the beginning.
          </p>
        </div>
      </section>

      <section id="contact" className="cta section">
        <p className="eyebrow">Need help?</p>
        <h2>Let&apos;s make your next celebration sweeter.</h2>
        <a className="button button-primary" href="https://wa.me/" target="_blank">
          WhatsApp Us
        </a>
      </section>
    </main>
  );
}
